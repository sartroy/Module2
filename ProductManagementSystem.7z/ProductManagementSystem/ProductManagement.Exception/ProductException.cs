﻿using System;
using System.Runtime.Serialization;

namespace ProductManagement.Exception
{
    [Serializable]
    public class ProductException : System.Exception
    {
        public ProductException()
        {
        }

        public ProductException(string message) : base(message)
        {
        }

        public ProductException(string message, System.Exception innerException) : base(message, innerException)
        {
        }

        protected ProductException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}