﻿using System;
using System.Data.SqlClient;
using ProductManagement.Entity;
using System.Configuration;
using System.Data;

namespace ProductManagement.DataAccessLayer
{
    public class ProductDL
    {
        SqlCommand cmd = new SqlCommand();
        static string Con = string.Empty;
        SqlConnection con1;

        static ProductDL()
        {
            Con = ConfigurationManager.ConnectionStrings["Con"].ConnectionString;
        }
        public ProductDL()
        {
            con1 = new SqlConnection(Con);
        }

        public int AddProduct(Product p)
        {
           
            try
            {
                cmd.CommandText = "ArRai.AddProduct";
                cmd.Connection = con1;
                cmd.CommandType = CommandType.StoredProcedure;
                                
                cmd.Parameters.AddWithValue("@sNumber", p.SerialNumber);
                cmd.Parameters.AddWithValue("@pName", p.ProductName);
                cmd.Parameters.AddWithValue("@bname", p.BrandName);
                cmd.Parameters.AddWithValue("@pType", p.ProductType);
                cmd.Parameters.AddWithValue("@pDesc",p.ProductDesc);
                cmd.Parameters.AddWithValue("@price", p.Price);


                con1.Open();
                int Rowaffected=cmd.ExecuteNonQuery();
                return Rowaffected;
                

            }
            catch (System.Exception)
            {

                throw;
            }
            finally
            {
                con1.Close();
            }

        }

        public DataTable ListEmp()
        {
            DataTable dt = null;
            try
            {

                cmd.CommandText = "ArRai.List";
                cmd.Connection = con1;
                cmd.CommandType = CommandType.StoredProcedure;

                con1.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (System.Exception)
            {

                throw;
            }
            return dt;
        }
    }
    }
