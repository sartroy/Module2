﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using DataAccessLayer;
using Exceptions;
using System.Data;
using System.Text.RegularExpressions;

namespace BusinessLayer
{
    public class EmployeeBL
    {
        public bool Validate_Employee(Employee pobj)
        {
            StringBuilder sb = new StringBuilder();
            bool Validate_Employee = true;
            if (pobj.EmployeeName == string.Empty)
            {
                Validate_Employee = false;
                sb.Append(Environment.NewLine + "Employee Name Required");
            }
            //if(!Regex.IsMatch(pobj.EmployeeID, "[E][-][0-9]{4}"))
            //{
            //    Validate_Employee = false;
            //    sb.Append(Environment.NewLine + "Valid Employee Id reqired");
            //}
            if(pobj.EmployeeSalary==0)
            {
                Validate_Employee = false;
                sb.Append(Environment.NewLine + "Employee cannot be Zero");
            }
            if(pobj.Designation==string.Empty)
            {
                Validate_Employee = false;
                sb.Append(Environment.NewLine + " Designation required");
            }
            if (Validate_Employee == false)
                throw new EmployeeException(sb.ToString());
            return Validate_Employee;
        }

        public int AddEmployee(Employee pobj)
        {

            int leno = 0;
            try
            {
                if (Validate_Employee(pobj))
                {
                    EmployeeDal pd = new EmployeeDal();
                    return pd.AddEmployee(pobj);
                }
            }
            catch (EmployeeException)
            {
                throw;
            }
            return leno;
        }
        public DataTable Display()
        {
            try
            {
                EmployeeDal pd = new EmployeeDal();
                return pd.Display();
            }
            catch (EmployeeException)
            {
                throw;
            }
        }
        

    }
}
