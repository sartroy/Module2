﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using Exceptions;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace DataAccessLayer
{
    public class EmployeeDal
    {
        
            static string conStr = string.Empty;
            SqlConnection con = null;
            SqlCommand cmd = null;



            static EmployeeDal()
            {
                conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

            }

            public EmployeeDal()
            {
                con = new SqlConnection(conStr);

            }
        public int AddEmployee(Employee pboj)
        {
            //int pid = 0;
            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 
                cmd = new SqlCommand();
                cmd.CommandText = "EmployeeEcl.AddEmployee";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                //cmd.Parameters.Add("@pId", SqlDbType.Int);
                //cmd.Parameters["@pId"].Direction = ParameterDirection.Output;

                cmd.Parameters.AddWithValue("@eName", pboj.EmployeeName);
                cmd.Parameters.AddWithValue("@eID", pboj.EmployeeID);
                cmd.Parameters.AddWithValue("@eSal", pboj.EmployeeSalary);
                cmd.Parameters.AddWithValue("@Designation", pboj.Designation);
                cmd.Parameters.AddWithValue("@datenow", pboj.DateNow);
                


                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                //pid = int.Parse(cmd.Parameters["@pId"].Value.ToString());
                return noOfRowsAffected;
            }
            catch (EmployeeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            
        }
        public DataTable Display()
        {
            DataTable dt = null;

            try
            {
                // con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "EmployeeEcl.Display";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (EmployeeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
     
    }
}
