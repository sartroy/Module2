﻿using System;

namespace Entities
{
    public class Employee
    {
        public string EmployeeName { get; set; }
        public string EmployeeID { get; set; }
        public double EmployeeSalary { get; set; }
        public string Designation { get; set; }
        public DateTime DateNow { get; set; }
    }
    public enum Designation { HR, ASE, SE, Consultant, VC };
}