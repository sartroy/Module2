﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Entities;
using Exceptions;
using BusinessLayer;
using System.Data;

namespace EmployeeManagementSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Employee p = new Employee
                {
                    EmployeeName = txtName.Text,
                    EmployeeID = txtID.Text,
                    EmployeeSalary = double.Parse(txtSalary.Text),
                   DateNow = DPDate.SelectedDate.Value.Date,
                   Designation = cmbDesignation.SelectedValue.ToString()

                };
                EmployeeBL pb = new EmployeeBL();
                int added= pb.AddEmployee(p);
                if(added!=0)
                {
                    MessageBox.Show("Product Added Successfully");
                    DataTable dt = pb.Display();
                    if(dt != null)
                {
                        dgDisplay.ItemsSource = dt.DefaultView;
                    }
                else
                {
                        MessageBox.Show("Table is empty", "Product Management System");
                    }
                }
                MessageBox.Show("Employee Added Succesfully");
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message, "Employee Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Employee Management System");
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
             foreach (var item in Enum.GetValues(typeof(Designation)))
                {
                cmbDesignation.Items.Add(item);
                }
        //    try
        //    {
        //        EmployeeBL pb = new EmployeeBL();
        //        DataTable dt = pb.Display();
        //        if (dt != null)
        //        {
        //            dgDisplay.ItemsSource = dt.DefaultView;
        //        }
        //        else
        //        {
        //            MessageBox.Show("Table is empty", "Product Management System");
        //        }
        //    }
        //    catch (EmployeeException ex)
        //    {
        //        MessageBox.Show(ex.Message, "Product Management System");
        //    }
        //    catch (SystemException ex)
        //    {
        //        MessageBox.Show(ex.Message, "Product Management System");
        //    }
        //}

        //private void Button1_Click(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        EmployeeBL pb = new EmployeeBL();
        //        Employee p = pb.Search(int.Parse(txtSearch.Text));
        //        if (p != null)
        //        {
        //            txtName.Text = p.EmployeeName;
        //            txtSalary.Text = p.EmployeeSalary.ToString();
        //            txtID1.Text = p.EmployeeID.ToString();
        //            txtDate.Text = p.DateNow.ToString();
        //            txtDes.Text = p.Designation;

        //        }
        //        else
        //        {
                    
        //            MessageBox.Show
        //                (string.Format("Product with id {0} does not exists.", txtSearch.Text),
        //                "Product Management System");
        //        }
        //    }
        //    catch (EmployeeException ex)
        //    {
        //        MessageBox.Show(ex.Message, "Product Management System");
        //    }
        //    catch (SystemException ex)
        //    {
        //        MessageBox.Show(ex.Message, "Product Management System");
        //    }
        }
    }
}
