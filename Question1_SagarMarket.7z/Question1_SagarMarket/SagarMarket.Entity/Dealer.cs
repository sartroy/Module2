﻿namespace SagarMarket.Entity
{
    public class Dealer
    {
        public string dealerPhoneNo;
        public string DealerId { get; set; }
        public string Dealername { get; set; }
        public string DealerAddress { get; set; }
        public string DealerEmailId { get; set; }
        public DealerStatus1 DealerStatus;
        public ProductCategory1 DealerProductCategory;


        public enum DealerStatus1
        { Active=1, InActive=2}

        public enum ProductCategory1
        { Grocery=1,Bakery_product=2,Vegetables=3,fruits=4}
    }
}