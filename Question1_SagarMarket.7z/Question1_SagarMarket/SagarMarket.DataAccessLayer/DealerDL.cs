﻿using System;
using System.Collections.Generic;
using SagarMarket.Entity;
using SagarMarket.Exception;

namespace SagarMarket.DataAccessLayer
{
    public class DealerDL
    {
        static List<Dealer> dealerList = new List<Dealer>();
        public bool AddVisitor(Dealer dealer)
        {
            bool dealerAdded = false;
            try
            {
                dealerList.Add(dealer);
                dealerAdded = true;
            }
            catch (SystemException ex)
            {
                throw new DealerException(ex.Message);
            }
            catch (System.Exception)
            {

                throw;
            }

            return dealerAdded;


        }

        public List<Dealer> SearchDealerDAL(string product)
        {
            List<Dealer> dealer = new List<Dealer>();
            try
            {

                foreach (var item in dealerList)
                {
                    dealer = dealerList.FindAll(deal => deal.DealerProductCategory.Equals(product));
                }

                Dealer dl = new Dealer();

            }
            catch (SystemException ex)
            {
                throw new DealerException(ex.Message);
            }

            catch (System.Exception)
            {

                throw;
            }
            return dealer;
        }

        

    }
}