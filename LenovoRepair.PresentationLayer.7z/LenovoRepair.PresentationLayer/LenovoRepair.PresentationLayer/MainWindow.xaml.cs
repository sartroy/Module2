﻿using LenovoRepair.BussinesLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LenovoRepair.Entities;
using System.Data;

namespace LenovoRepair.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public enum PossibleDeviceType
        {
            Laptop = 0,
            Mobile = 1,
            Desktop = 2

        }
        public MainWindow()
        {   
            InitializeComponent();
            comboBox1.ItemsSource = Enum.GetValues(typeof(PossibleDeviceType));
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            try
            {  
                LenovoEntities l = new LenovoEntities
                {
                    ServiceID = txtbox1.Text,
                    Date = datepicker1.SelectedDate.Value.Date,
                    CustomerName = txtbox2.Text,
                    ContactNumber = long.Parse(txtbox5.Text),
                    DeviceType = comboBox1.Text,
                    ProductId = int.Parse(txtbox3.Text),
                    IssueDescription = txtbox4.Text



                };

                
                    LenovoBll bll = new LenovoBll();
                    int a = bll.AddDetails(l);
                    if (a != 0)
                    {
                        MessageBox.Show("Added SuccessFully");
                    }

                    DataTable dt = bll.Display();
                    if (dt != null)
                    {
                        dataGrid1.ItemsSource = dt.DefaultView;
                    }
                    else
                    {

                        MessageBox.Show("Table is Empty");
                    }
                
            }
            catch (SystemException)
            {
                throw;
            }
        }
    }
}
