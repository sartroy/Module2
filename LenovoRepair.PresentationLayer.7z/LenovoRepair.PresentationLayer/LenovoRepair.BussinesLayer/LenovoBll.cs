﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using LenovoRepair.DataAccessLayer;
using LenovoRepair.Entities;
using LenovoRepair.Exceptions;


namespace LenovoRepair.BussinesLayer
{
    public class LenovoBll
    { public bool Validate_Customer(LenovoEntities l)
        {
            StringBuilder sb = new StringBuilder();
            bool validatecust = true;
            if (l.CustomerName == string.Empty)
            {
                validatecust = false;
                sb.Append(Environment.NewLine + "owner Name Required");

            }
            if (l.DeviceType == string.Empty)
            {
                validatecust = false;
                sb.Append(Environment.NewLine + "Device type  required");

            }
            if (l.ContactNumber > 9999999999 || l.ContactNumber < 8000000000)

            {
                validatecust = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }
            if (l.IssueDescription == string.Empty)
            {
                validatecust = false;
                sb.Append(Environment.NewLine + "Contact Person name reqired");

            }

            if (!Regex.IsMatch(l.ServiceID,"[A]{1}[D]{1}[0-9]{4}"))
            {
                validatecust = false;
                sb.Append(Environment.NewLine + "Valid Service Id reqired");
            }
            if (validatecust == false)
                throw new LenovoException(sb.ToString());
            return validatecust;

        }
        public int AddDetails(LenovoEntities prod)
        {
            int leno = 0; 
            try
            {   if (Validate_Customer(prod))
                {
                    LenovoDal dal = new LenovoDal();

                    leno = dal.AddDetails(prod);
                }
                


            }
            catch (LenovoException)
            {
                throw;
            }

            return leno;
        }
        public DataTable Display()
        {
            try
            {   
                LenovoDal dal = new LenovoDal();
                return dal.Display();
            }
            catch (LenovoException)
            {
                throw;
            }

        }



    }
}
